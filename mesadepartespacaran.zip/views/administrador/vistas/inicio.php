<h1 class="h3 mb-4 text-gray-800">Bienvenido administrador</h1>
<p>Contenido inicial...</p>
